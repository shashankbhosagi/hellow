/* original parser id follows */
/* yysccsid[] = "@(#)yaccpar	1.9 (Berkeley) 02/21/93" */
/* (use YYMAJOR/YYMINOR for ifdefs dependent on parser version) */

#define YYBYACC 1
#define YYMAJOR 1
#define YYMINOR 9
#define YYPATCH 20140715

#define YYEMPTY        (-1)
#define yyclearin      (yychar = YYEMPTY)
#define yyerrok        (yyerrflag = 0)
#define YYRECOVERING() (yyerrflag != 0)
#define YYENOMEM       (-2)
#define YYEOF          0
#define YYPREFIX "yy"

#define YYPURE 0

#line 2 "4.y"
#include <stdio.h>
#line 23 "y.tab.c"

#if ! defined(YYSTYPE) && ! defined(YYSTYPE_IS_DECLARED)
/* Default: YYSTYPE is the semantic value type. */
typedef int YYSTYPE;
# define YYSTYPE_IS_DECLARED 1
#endif

/* compatibility with bison */
#ifdef YYPARSE_PARAM
/* compatibility with FreeBSD */
# ifdef YYPARSE_PARAM_TYPE
#  define YYPARSE_DECL() yyparse(YYPARSE_PARAM_TYPE YYPARSE_PARAM)
# else
#  define YYPARSE_DECL() yyparse(void *YYPARSE_PARAM)
# endif
#else
# define YYPARSE_DECL() yyparse(void)
#endif

/* Parameters sent to lex. */
#ifdef YYLEX_PARAM
# define YYLEX_DECL() yylex(void *YYLEX_PARAM)
# define YYLEX yylex(YYLEX_PARAM)
#else
# define YYLEX_DECL() yylex(void)
# define YYLEX yylex()
#endif

/* Parameters sent to yyerror. */
#ifndef YYERROR_DECL
#define YYERROR_DECL() yyerror(const char *s)
#endif
#ifndef YYERROR_CALL
#define YYERROR_CALL(msg) yyerror(msg)
#endif

extern int YYPARSE_DECL();

#define id 257
#define NUM 258
#define OR 259
#define AND 260
#define NOT 261
#define relop 262
#define TRUE 263
#define FALSE 264
#define INC 265
#define DEC 266
#define IF 267
#define ELSE 268
#define DO 269
#define WHILE 270
#define uminus 271
#define FOR 272
#define SWITCH 273
#define CASE 274
#define BREAK 275
#define DEFAULT 276
#define YYERRCODE 256
typedef short YYINT;
static const YYINT yylhs[] = {                           -1,
    0,    0,    1,    1,    1,    1,    1,    1,    1,    8,
   10,   10,   10,    2,    9,    9,    9,    9,    9,    9,
    9,    9,    3,   11,   11,   11,   11,   11,   11,    4,
    5,    6,    7,   12,   12,   13,   13,   13,   13,   13,
};
static const YYINT yylen[] = {                            2,
    2,    1,    2,    1,    1,    1,    1,    1,    1,    7,
    6,    7,    9,    3,    3,    3,    3,    3,    3,    2,
    1,    1,    7,    3,    3,    2,    3,    1,    1,   11,
    7,    9,   11,    1,    3,    1,    2,    2,    2,    2,
};
static const YYINT yydefred[] = {                         0,
    0,    0,    0,    0,    0,    0,    0,    2,    0,    4,
    5,    6,    7,    8,    9,    0,    0,    0,    0,    0,
    0,    1,    3,   21,   22,    0,    0,    0,    0,   28,
   29,    0,    0,    0,   34,    0,    0,   20,    0,    0,
    0,    0,    0,    0,   26,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,   27,    0,
   25,    0,    0,    0,    0,   35,    0,    0,    0,    0,
    0,    0,    0,    0,    0,   31,    0,    0,    0,    0,
    0,    0,   10,    0,    0,   37,   39,   38,   40,    0,
    0,    0,   32,    0,    0,    0,    0,    0,   30,   33,
    0,    0,   12,    0,    0,
};
static const YYINT yydgoto[] = {                          7,
    8,    9,   10,   11,   12,   13,   14,   15,   27,   73,
   32,   36,   81,
};
static const YYINT yysindex[] = {                       -82,
  -40,  -20,  -78,    6,    7,    8,  -82,    0,   -7,    0,
    0,    0,    0,    0,    0,  -42,  -68,  -82,  -68, -204,
  -42,    0,    0,    0,    0,  -42,   -5, -193,  -68,    0,
    0,  -41, -117,  -39,    0,   19,  -29,    0,  -42,  -42,
  -42,  -42,  -42, -186,    0,  -68,  -68,  -49, -195,  -47,
  -68, -204,  -43,  -15,  -15,   -6,   -6,   -6,    0, -175,
    0,  -82,   47,  -82,  -52,    0, -182, -110,  -68, -103,
 -127,  -42,   -1, -163,  -37,    0,  -56, -142, -128,   87,
   91,  -17,    0,   11,   76,    0,    0,    0,    0,   21,
  -82,  -82,    0,  -82, -124,  -96,  -89,   82,    0,    0,
 -257,   84,    0,  -82,  -82,
};
static const YYINT yyrindex[] = {                         0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,  -10,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,   23,   50,   59,   69,   78,    0,  -35,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    1,    0,    0,    0,    0,    0,  117,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
   40,    0,    0,    0,   54,
};
static const YYINT yygindex[] = {                        -8,
    2,   -9,    0,    0,    0,    0,    0,    0,   18,   71,
    4,  111,    0,
};
#define YYTABLESIZE 276
static const YYINT yytable[] = {                         48,
   23,   50,   26,   85,   16,   24,   71,   49,   22,   33,
   35,   53,   41,   39,   74,   40,   72,   42,  102,   17,
   16,   76,   34,   24,   41,   39,   41,   40,   99,   42,
   14,   42,   45,   14,   22,  100,   41,   39,   37,   40,
   91,   42,   66,   38,   18,   19,   20,   21,   14,   60,
   61,   23,    1,   68,   65,   70,   54,   55,   56,   57,
   58,   35,   52,   15,   43,   15,   15,   15,   44,   22,
   59,   22,   75,   62,   63,   64,   43,   51,   43,   67,
   15,   15,   95,   96,   47,   97,   69,   43,   43,   82,
   16,   72,   16,   16,   16,  105,   22,   22,   22,   17,
   17,   17,   17,   17,   84,   17,   22,   16,   16,   18,
   18,   18,   18,   18,   88,   18,   17,   17,   19,   19,
   19,   19,   19,   83,   19,   23,   18,   18,   89,   77,
   52,   90,    1,   92,   93,   19,   19,   78,   79,    1,
  101,  104,    2,   94,    3,    4,    1,    5,    6,    2,
   98,    3,    4,    1,    5,    6,    2,   36,    3,    4,
    1,    5,    6,    2,   11,    3,    4,    1,    5,    6,
    2,  103,    3,    4,    1,    5,    6,    2,   13,    3,
    4,   80,    5,    6,    2,    0,    3,    4,   28,    5,
    6,    0,   29,    0,   30,   31,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,   46,   47,   86,   87,
    0,    0,    0,    0,   24,   25,    0,   46,   47,   46,
   47,   46,   47,   24,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,   23,    0,    0,
    0,    0,    0,    0,    0,    0,    0,   23,    0,   23,
   23,    0,   23,   23,    0,   23,
};
static const YYINT yycheck[] = {                         41,
    0,   41,   45,   41,   61,   41,   59,  125,    7,   18,
   20,   41,   42,   43,  125,   45,  274,   47,  276,   40,
   61,  125,   19,   59,   42,   43,   42,   45,  125,   47,
   41,   47,   29,   44,   33,  125,   42,   43,   21,   45,
   58,   47,   52,   26,  123,   40,   40,   40,   59,   46,
   47,   59,  257,   62,   51,   64,   39,   40,   41,   42,
   43,   71,   44,   41,   94,   43,   44,   45,  262,   68,
  257,   70,   69,  123,  270,  123,   94,   59,   94,  123,
   58,   59,   91,   92,  260,   94,   40,   94,   94,   72,
   41,  274,   43,   44,   45,  104,   95,   96,   97,   41,
   42,   43,   44,   45,  268,   47,  105,   58,   59,   41,
   42,   43,   44,   45,  257,   47,   58,   59,   41,   42,
   43,   44,   45,  125,   47,  125,   58,   59,  257,  257,
   44,   41,  257,  123,   59,   58,   59,  265,  266,  257,
   59,   58,  267,  123,  269,  270,  257,  272,  273,  267,
  275,  269,  270,  257,  272,  273,  267,   41,  269,  270,
  257,  272,  273,  267,  125,  269,  270,  257,  272,  273,
  267,  101,  269,  270,  257,  272,  273,  267,  125,  269,
  270,   71,  272,  273,  267,   -1,  269,  270,  257,  272,
  273,   -1,  261,   -1,  263,  264,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,  259,  260,  265,  266,
   -1,   -1,   -1,   -1,  257,  258,   -1,  259,  260,  259,
  260,  259,  260,  259,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,  257,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,  267,   -1,  269,
  270,   -1,  272,  273,   -1,  275,
};
#define YYFINAL 7
#ifndef YYDEBUG
#define YYDEBUG 0
#endif
#define YYMAXTOKEN 276
#define YYUNDFTOKEN 292
#define YYTRANSLATE(a) ((a) > YYMAXTOKEN ? YYUNDFTOKEN : (a))
#if YYDEBUG
static const char *const yyname[] = {

"end-of-file",0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,"'('","')'","'*'","'+'","','","'-'",0,"'/'",0,0,0,0,0,0,0,0,0,0,
"':'","';'",0,"'='",0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,"'^'",0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,"'{'",0,"'}'",
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,"id","NUM","OR","AND","NOT","relop","TRUE","FALSE","INC",
"DEC","IF","ELSE","DO","WHILE","uminus","FOR","SWITCH","CASE","BREAK","DEFAULT",
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,"illegal-symbol",
};
static const char *const yyrule[] = {
"$accept : S1",
"S1 : S1 S",
"S1 : S",
"S : AS ';'",
"S : IFS",
"S : IFES",
"S : WS",
"S : DWS",
"S : FORS",
"S : SS",
"SS : SWITCH '(' E ')' '{' CV '}'",
"CV : CASE E ':' S1 BREAK ';'",
"CV : CASE E ':' S1 BREAK ';' CV",
"CV : CASE E ':' S1 BREAK ';' DEFAULT ':' S1",
"AS : id '=' E",
"E : E '+' E",
"E : E '-' E",
"E : E '*' E",
"E : E '/' E",
"E : E '^' E",
"E : '-' E",
"E : id",
"E : NUM",
"IFS : IF '(' BE ')' '{' S1 '}'",
"BE : BE OR BE",
"BE : BE AND BE",
"BE : NOT BE",
"BE : id relop id",
"BE : TRUE",
"BE : FALSE",
"IFES : IF '(' BE ')' '{' S1 '}' ELSE '{' S1 '}'",
"WS : WHILE '(' BE ')' '{' S1 '}'",
"DWS : DO '{' S1 '}' WHILE '(' BE ')' ';'",
"FORS : FOR '(' IS ';' BE ';' MS ')' '{' S1 '}'",
"IS : AS",
"IS : IS ',' AS",
"MS : IS",
"MS : id INC",
"MS : INC id",
"MS : id DEC",
"MS : DEC id",

};
#endif

int      yydebug;
int      yynerrs;

int      yyerrflag;
int      yychar;
YYSTYPE  yyval;
YYSTYPE  yylval;

/* define the initial stack-sizes */
#ifdef YYSTACKSIZE
#undef YYMAXDEPTH
#define YYMAXDEPTH  YYSTACKSIZE
#else
#ifdef YYMAXDEPTH
#define YYSTACKSIZE YYMAXDEPTH
#else
#define YYSTACKSIZE 10000
#define YYMAXDEPTH  10000
#endif
#endif

#define YYINITSTACKSIZE 200

typedef struct {
    unsigned stacksize;
    YYINT    *s_base;
    YYINT    *s_mark;
    YYINT    *s_last;
    YYSTYPE  *l_base;
    YYSTYPE  *l_mark;
} YYSTACKDATA;
/* variables for the parser stack */
static YYSTACKDATA yystack;
#line 70 "4.y"
void main()
{
yyparse();
}
int yyerror(char *msg)
{
printf("%s\n",msg);
}
#line 313 "y.tab.c"

#if YYDEBUG
#include <stdio.h>		/* needed for printf */
#endif

#include <stdlib.h>	/* needed for malloc, etc */
#include <string.h>	/* needed for memset */

/* allocate initial stack or double stack size, up to YYMAXDEPTH */
static int yygrowstack(YYSTACKDATA *data)
{
    int i;
    unsigned newsize;
    YYINT *newss;
    YYSTYPE *newvs;

    if ((newsize = data->stacksize) == 0)
        newsize = YYINITSTACKSIZE;
    else if (newsize >= YYMAXDEPTH)
        return YYENOMEM;
    else if ((newsize *= 2) > YYMAXDEPTH)
        newsize = YYMAXDEPTH;

    i = (int) (data->s_mark - data->s_base);
    newss = (YYINT *)realloc(data->s_base, newsize * sizeof(*newss));
    if (newss == 0)
        return YYENOMEM;

    data->s_base = newss;
    data->s_mark = newss + i;

    newvs = (YYSTYPE *)realloc(data->l_base, newsize * sizeof(*newvs));
    if (newvs == 0)
        return YYENOMEM;

    data->l_base = newvs;
    data->l_mark = newvs + i;

    data->stacksize = newsize;
    data->s_last = data->s_base + newsize - 1;
    return 0;
}

#if YYPURE || defined(YY_NO_LEAKS)
static void yyfreestack(YYSTACKDATA *data)
{
    free(data->s_base);
    free(data->l_base);
    memset(data, 0, sizeof(*data));
}
#else
#define yyfreestack(data) /* nothing */
#endif

#define YYABORT  goto yyabort
#define YYREJECT goto yyabort
#define YYACCEPT goto yyaccept
#define YYERROR  goto yyerrlab

int
YYPARSE_DECL()
{
    int yym, yyn, yystate;
#if YYDEBUG
    const char *yys;

    if ((yys = getenv("YYDEBUG")) != 0)
    {
        yyn = *yys;
        if (yyn >= '0' && yyn <= '9')
            yydebug = yyn - '0';
    }
#endif

    yynerrs = 0;
    yyerrflag = 0;
    yychar = YYEMPTY;
    yystate = 0;

#if YYPURE
    memset(&yystack, 0, sizeof(yystack));
#endif

    if (yystack.s_base == NULL && yygrowstack(&yystack) == YYENOMEM) goto yyoverflow;
    yystack.s_mark = yystack.s_base;
    yystack.l_mark = yystack.l_base;
    yystate = 0;
    *yystack.s_mark = 0;

yyloop:
    if ((yyn = yydefred[yystate]) != 0) goto yyreduce;
    if (yychar < 0)
    {
        if ((yychar = YYLEX) < 0) yychar = YYEOF;
#if YYDEBUG
        if (yydebug)
        {
            yys = yyname[YYTRANSLATE(yychar)];
            printf("%sdebug: state %d, reading %d (%s)\n",
                    YYPREFIX, yystate, yychar, yys);
        }
#endif
    }
    if ((yyn = yysindex[yystate]) && (yyn += yychar) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yychar)
    {
#if YYDEBUG
        if (yydebug)
            printf("%sdebug: state %d, shifting to state %d\n",
                    YYPREFIX, yystate, yytable[yyn]);
#endif
        if (yystack.s_mark >= yystack.s_last && yygrowstack(&yystack) == YYENOMEM)
        {
            goto yyoverflow;
        }
        yystate = yytable[yyn];
        *++yystack.s_mark = yytable[yyn];
        *++yystack.l_mark = yylval;
        yychar = YYEMPTY;
        if (yyerrflag > 0)  --yyerrflag;
        goto yyloop;
    }
    if ((yyn = yyrindex[yystate]) && (yyn += yychar) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yychar)
    {
        yyn = yytable[yyn];
        goto yyreduce;
    }
    if (yyerrflag) goto yyinrecovery;

    YYERROR_CALL("syntax error");

    goto yyerrlab;

yyerrlab:
    ++yynerrs;

yyinrecovery:
    if (yyerrflag < 3)
    {
        yyerrflag = 3;
        for (;;)
        {
            if ((yyn = yysindex[*yystack.s_mark]) && (yyn += YYERRCODE) >= 0 &&
                    yyn <= YYTABLESIZE && yycheck[yyn] == YYERRCODE)
            {
#if YYDEBUG
                if (yydebug)
                    printf("%sdebug: state %d, error recovery shifting\
 to state %d\n", YYPREFIX, *yystack.s_mark, yytable[yyn]);
#endif
                if (yystack.s_mark >= yystack.s_last && yygrowstack(&yystack) == YYENOMEM)
                {
                    goto yyoverflow;
                }
                yystate = yytable[yyn];
                *++yystack.s_mark = yytable[yyn];
                *++yystack.l_mark = yylval;
                goto yyloop;
            }
            else
            {
#if YYDEBUG
                if (yydebug)
                    printf("%sdebug: error recovery discarding state %d\n",
                            YYPREFIX, *yystack.s_mark);
#endif
                if (yystack.s_mark <= yystack.s_base) goto yyabort;
                --yystack.s_mark;
                --yystack.l_mark;
            }
        }
    }
    else
    {
        if (yychar == YYEOF) goto yyabort;
#if YYDEBUG
        if (yydebug)
        {
            yys = yyname[YYTRANSLATE(yychar)];
            printf("%sdebug: state %d, error recovery discards token %d (%s)\n",
                    YYPREFIX, yystate, yychar, yys);
        }
#endif
        yychar = YYEMPTY;
        goto yyloop;
    }

yyreduce:
#if YYDEBUG
    if (yydebug)
        printf("%sdebug: state %d, reducing by rule %d (%s)\n",
                YYPREFIX, yystate, yyn, yyrule[yyn]);
#endif
    yym = yylen[yyn];
    if (yym)
        yyval = yystack.l_mark[1-yym];
    else
        memset(&yyval, 0, sizeof yyval);
    switch (yyn)
    {
case 3:
#line 18 "4.y"
	{printf("Assignment statement accepted \n");}
break;
case 4:
#line 19 "4.y"
	{printf("If statement is accepted \n");}
break;
case 5:
#line 20 "4.y"
	{printf("If else statement is accepted\n");}
break;
case 6:
#line 21 "4.y"
	{printf("While statement is accepted\n");}
break;
case 7:
#line 22 "4.y"
	{printf("Do while statement is accepted\n");}
break;
case 8:
#line 23 "4.y"
	{printf("For statement is accepted\n");}
break;
case 9:
#line 24 "4.y"
	{printf("Switch statement is accepted");}
break;
#line 543 "y.tab.c"
    }
    yystack.s_mark -= yym;
    yystate = *yystack.s_mark;
    yystack.l_mark -= yym;
    yym = yylhs[yyn];
    if (yystate == 0 && yym == 0)
    {
#if YYDEBUG
        if (yydebug)
            printf("%sdebug: after reduction, shifting from state 0 to\
 state %d\n", YYPREFIX, YYFINAL);
#endif
        yystate = YYFINAL;
        *++yystack.s_mark = YYFINAL;
        *++yystack.l_mark = yyval;
        if (yychar < 0)
        {
            if ((yychar = YYLEX) < 0) yychar = YYEOF;
#if YYDEBUG
            if (yydebug)
            {
                yys = yyname[YYTRANSLATE(yychar)];
                printf("%sdebug: state %d, reading %d (%s)\n",
                        YYPREFIX, YYFINAL, yychar, yys);
            }
#endif
        }
        if (yychar == YYEOF) goto yyaccept;
        goto yyloop;
    }
    if ((yyn = yygindex[yym]) && (yyn += yystate) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yystate)
        yystate = yytable[yyn];
    else
        yystate = yydgoto[yym];
#if YYDEBUG
    if (yydebug)
        printf("%sdebug: after reduction, shifting from state %d \
to state %d\n", YYPREFIX, *yystack.s_mark, yystate);
#endif
    if (yystack.s_mark >= yystack.s_last && yygrowstack(&yystack) == YYENOMEM)
    {
        goto yyoverflow;
    }
    *++yystack.s_mark = (YYINT) yystate;
    *++yystack.l_mark = yyval;
    goto yyloop;

yyoverflow:
    YYERROR_CALL("yacc stack overflow");

yyabort:
    yyfreestack(&yystack);
    return (1);

yyaccept:
    yyfreestack(&yystack);
    return (0);
}
